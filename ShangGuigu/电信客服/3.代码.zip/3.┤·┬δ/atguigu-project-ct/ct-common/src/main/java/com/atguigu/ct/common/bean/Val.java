package com.atguigu.ct.common.bean;

/**
 * 值对象接口
 */
public interface Val {
    public void setValue( Object val );
    public Object getValue();
}
