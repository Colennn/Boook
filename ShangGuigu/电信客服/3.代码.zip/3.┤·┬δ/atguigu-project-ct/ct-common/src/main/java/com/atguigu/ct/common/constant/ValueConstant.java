package com.atguigu.ct.common.constant;

/**
 * 常量类
 */
public class ValueConstant {
    public static final Integer REGION_COUNT = 6;
}
